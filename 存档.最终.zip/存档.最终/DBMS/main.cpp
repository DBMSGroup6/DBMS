﻿#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
//    QApplication a(argc, argv);
//    MainWindow w;

//    w.setWindowTitle("梦圆带飞DBMS");//为窗口添加图标与文本
//    QIcon icon_tdatabase;
//    icon_tdatabase.addFile("DBMS/res/feel.png");
//    w.setWindowIcon(icon_tdatabase);

//    w.show();
//    return a.exec();
    QApplication a(argc, argv);
    login w;


    w.setWindowTitle("梦圆带飞DBMS");//为窗口添加图标与文本
    QIcon icon_tdatabase;
    icon_tdatabase.addFile("DBMS/res/feel.png");
    w.setWindowIcon(icon_tdatabase);

    w.setAutoFillBackground(true);
    QPalette palette;
    QPixmap pixmap("DBMS/res/sky.jpg");
    palette.setBrush(QPalette::Window, QBrush(pixmap));
    w.setPalette(palette);

    w.show();
    return a.exec();
}
