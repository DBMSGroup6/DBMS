#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QFileDialog>
#include <QDir>
#include <QDebug>
#include <qdebug.h>
#include<QFileDialog>
#include <QTableView>
#include <QStandardItemModel>
#include <table.h>
#include <field.h>
#include <dmdao.h>
#include <qtextcodec.h>
#include <QTextCodec>
#include <QPushButton>
#include <QMenu>
#include <QMessageBox>
#include <QCloseEvent>
#include <QMap>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <tree.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void init();
    bool Parse(QString sql);//解析
    QString match(QString sql);
    bool Select(QString database,QString sql);
    bool Insert(QString database,QString sql);
    bool Delete(QString database,QString sql);
    bool Update(QString database,QString sql);
    void Exec();//执行

protected:
    void closeEvent(QCloseEvent *event);

private slots:

    void on_open_triggered();

    void on_addtable_triggered();

    void on_findtable_triggered();

    void on_backbutton_clicked();

    void on_pushButton_clicked();

    void on_clearbutton_clicked();

    void on_readtable(QString,QString);

    void on_readdb_triggered();

    void on_treeWidget_itemSelectionChanged();

    void png();

private:
    Ui::MainWindow *ui;
    QString filename;
    QString dataname;

    QStringList sqlList;
    QString sql;
    QQueue<QString> queue;
    QVector<QString> judge;
    QMap<QString,QVector<QString>> map;
    dmDao dao;
};
#endif // MAINWINDOW_H
