#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    png();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::init(){
     ui->textEdit->setText("");
}

void MainWindow::closeEvent(QCloseEvent *event){
    //窗口关闭时询问是否退出
       QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要退出本系统吗？",
                          QMessageBox::Yes|QMessageBox::No);
        if (result==QMessageBox::Yes)
            event->accept();
        else
            event->ignore();
}

void MainWindow::png()
{
    QIcon icon_tadd;
    icon_tadd.addFile(tr("DBMS/res/add.png"));
    ui->tadd->setIcon(icon_tadd);

    QIcon icon_tdelete;
    icon_tdelete.addFile(tr("DBMS/res/delete.png"));
    ui->tdelete->setIcon(icon_tdelete);

    QIcon icon_tcorrect;
    icon_tcorrect.addFile(tr("DBMS/res/correct.png"));
    ui->tcorrect->setIcon(icon_tcorrect);

    QIcon icon_twrong;
    icon_twrong.addFile(tr("DBMS/res/wrong.png"));
    ui->twrong->setIcon(icon_twrong);

    QIcon icon_trefresh;
    icon_trefresh.addFile(tr("DBMS/res/refresh.png"));
    ui->trefresh->setIcon(icon_trefresh);
}

QString MainWindow::match(QString sql){
    QRegularExpression re("^delete\\sfrom\\s(\\w+)\\swhere\\s((?:[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+\\s(?:and|or)\\s)*[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+)");
    QRegularExpressionMatch match=re.match(sql);
    if(match.hasMatch())
    {
        QString matched1 = match.captured(1);
        ui->textEdit->append(matched1);
        QString matched2 = match.captured(2);
        ui->textEdit->append(matched2);
        QString matched3 = match.captured(3);
        ui->textEdit->append(matched3);
        QString matched4 = match.captured(4);
        ui->textEdit->append(matched4);
    }
     return "   ";
}

bool MainWindow::Parse(QString sql){
        //QString::trimmed() 移除字符串两端空白符
        //QString::simplified() 移除字符串两端空白符，使用单个空格字符代替字符串中出现的空白字符
        //remove(QRegExp("\\s)) 移除所有空白字符
        sql = sql.simplified();
        if(sql.isEmpty())
        {
            return false;
        }
        //全部转换为小写
        sql = sql.toLower();
        sqlList = sql.split(" ",QString::SkipEmptyParts);
        QString tem = sqlList[0];
        try{
            if(tem=="insert"){
                if(!Insert("test",sql)){
                    ui->textEdit->append("出现语法错误");
                }
                else{
                    ui->textEdit->append("插入成功");
                }
            }
            else if(tem=="delete"){
                if(!Delete("test",sql)){
                    ui->textEdit->append("出现语法错误");
                }
                else{
                    ui->textEdit->append("删除成功");
                }
            }
            else if(tem=="update"){
                if(!Update("test",sql)){
                    ui->textEdit->append("出现语法错误");
                }
                else{
                    ui->textEdit->append("更新成功");
                }
            }
            else if(tem=="select"){
                if(!Select("test",sql)){
                    ui->textEdit->append("出现语法错误");
                }
                else{
                    ui->textEdit->append("查询成功");
                }
            }
            else{
                ui->textEdit->append("出现语法错误");
            }
        }catch(QString exception){
            ui->textEdit->append(exception);
        }
    return true;
}

bool MainWindow::Insert(QString database,QString sql){
    try{
           QRegularExpression re("^insert\\sinto\\s([A-Za-z_]+)\\s?\\(((?:[A-Za-z_]+,)*[A-Za-z_]+)\\)\\svalues\\s?\\(((?:.*,)*.*)\\)");
           QRegularExpressionMatch match=re.match(sql);
           QString tableName;
           QString column;
           QString param;
           QStringList columnList;
           QStringList paramList;
           //有表参数
           if(match.hasMatch())
           {
               tableName = match.captured(1);
               column = match.captured(2);
               param = match.captured(3);
               //qDebug()<<param;
               columnList = column.split(",");
               paramList = param.split(",");
               if(columnList.length()==paramList.length()){
                   return dao.insertDao(tableName,columnList,paramList);
               }
           }
           //无表参数
           else{
               QRegularExpression reg("^insert\\sinto\\s([A-Za-z_]+)\\svalues\\s?\\(((?:.*,)*.*)\\)");
               match=reg.match(sql);
               if(match.hasMatch())
               {
                   tableName = match.captured(1);
                   param = match.captured(2);
                   paramList = param.split(",");
                   return dao.insertDao(tableName,columnList,paramList);
               }
               else{
                   throw QString("Does not conform to the grammar standard");
               }
           }
      }catch(QString exception){
          throw QString(exception);
      }
       return false;
}

bool MainWindow::Delete(QString database,QString sql){
    try{
           QString tableName;
           QStringList judgeList;
           QString judge;
           if(!sql.contains("where")){
               QRegularExpression re("^delete\\sfrom\\s(\\w+)");
               QRegularExpressionMatch match=re.match(sql);
               if(match.hasMatch())
               {
                   tableName = match.captured(1);
                   return dao.deleteDao(tableName,judgeList);
               }
               else{
                   throw QString("Does not conform to the grammar standard");
               }
           }
           else{
               QRegularExpression re("^delete\\sfrom\\s(\\w+)\\swhere\\s((?:[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+\\s(?:and|or)\\s)*[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+)");
               QRegularExpressionMatch match=re.match(sql);
               if(match.hasMatch())
               {
                   tableName = match.captured(1);
                   judge=match.captured(2);
                   judgeList = judge.split(" or ");
                   return dao.deleteDao(tableName,judgeList);
               }
               else{
                   throw QString("Does not conform to the grammar standard");
               }
           }
           }catch(QString exception){
               throw QString(exception);
           }

       return false;
}

bool MainWindow::Update(QString database,QString sql){
    try{
          QString tableName;
          QStringList judgeList;
          QString column;
          QString value;
          QString judge;
          if(!sql.contains("where")){
              QRegularExpression re("^update\\s(\\w+)\\sset\\s(\\w+)\\s?=\\s?(\\w+)");
              QRegularExpressionMatch match=re.match(sql);
              if(match.hasMatch())
              {
                  tableName = match.captured(1);
                  column = match.captured(2);
                  value = match.captured(3);
                  return dao.updateDao(tableName,column,value,judgeList);
              }
              else{
                  throw QString("Does not conform to the grammar standard");
              }
          }
          else{
              QRegularExpression re("^update\\s(\\w+)\\sset\\s(\\w+)\\s?=\\s?(\\w+)\\swhere\\s((?:[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+\\s(?:and|or)\\s)*[A-Za-z_]+\\s?(?:>|<|>=|<=|!=|=)\\s?\\w+)");
              QRegularExpressionMatch match=re.match(sql);
              if(match.hasMatch())
              {
                  tableName = match.captured(1);
                  column = match.captured(2);
                  value = match.captured(3);
                  judge=match.captured(4);
                  judgeList = judge.split(" or ");
                  return dao.updateDao(tableName,column,value,judgeList);
              }
              else{
                  throw QString("Does not conform to the grammar standard");
              }
          }
          }catch(QString exception){
              throw QString(exception);
          }

      return false;
}

bool MainWindow::Select(QString database,QString sql){
    try{
            Table t;
            QString table;
            QString column;
            QString judge;
            QString group;
            QString order;
            //QString having;
            bool desc=true;
            QStringList columnList;//SELECT ...
            QStringList tableList;//FROM ...
            QStringList judgeList;//WHERE
            QStringList groupList;//GROUP BY (...,)...
            QStringList orderList;//ORDER BY (...,)... (ASC)
            QRegularExpression re("^select\\s((?:\\w+,)*\\w+|\\*)\\sfrom\\s((?:\\w+,)*\\w+)"
                                  "(?:\\swhere\\s((?:[A-Za-z_\\.]+\\s?(?:>|<|>=|<=|!=|=)\\s?[\\w\\.]+"
                                  "\\s(?:and|or)\\s)*[A-Za-z_\\.]+\\s?(?:>|<|>=|<=|!=|=)\\s?[\\w\\.]+))?"
                                  "(?:\\sgroup\\sby\\s((?:\\w+,)*\\w+))?(?:\\sorder\\sby\\s((?:\\w+,)*\\w+)\\s?(?:asc|desc)?)?$");
            QRegularExpressionMatch match=re.match(sql);
            if(match.hasMatch()){
                if(sql.contains("where")){
                    QRegularExpression re("\\swhere\\s((?:[A-Za-z_\\.]+\\s?(?:>|<|>=|<=|!=|=)\\s?[\\w\\.]+\\s(?:and|or)\\s)*[A-Za-z_\\.]+\\s?(?:>|<|>=|<=|!=|=)\\s?[\\w\\.]+)");
                    QRegularExpressionMatch match=re.match(sql);
                    if(match.hasMatch())
                    {
                        judge = match.captured(1);
                        judgeList = judge.split(" or ");
                    }
                }
               if(sql.contains("group by")){
                   QRegularExpression re("\\sgroup\\sby\\s((?:\\w+,)*\\w+)");
                   QRegularExpressionMatch match=re.match(sql);
                   if(match.hasMatch())
                   {
                       group = match.captured(1);
                       groupList = group.split(",");
                   }
               }
               if(sql.contains("order by")){
                   QRegularExpression re("\\sorder\\sby\\s((?:\\w+,)*\\w+)\\s?(?:asc|desc)?");
                   QRegularExpressionMatch match=re.match(sql);
                   if(match.hasMatch())
                   {
                       if(match.captured(0).contains("asc")){
                           desc=false;
                       }
                       order = match.captured(1);
                       orderList = order.split(",");
                   }
               }
                QRegularExpression re("^select\\s((?:\\w+,)*\\w+|\\*)\\sfrom\\s((?:\\w+,)*\\w+)");
                QRegularExpressionMatch match=re.match(sql);
                if(match.hasMatch())
                {
                    column = match.captured(1);
                    table = match.captured(2);
                    tableList = table.split(",");
                    columnList = column.split(",");
                    t = dao.selectDao(tableList,columnList,judgeList,groupList,orderList,desc);
                     qDebug()<<"asc:";
                    //将表输出
                    QString row;
                    for(int i=0;i<t.getHead().size();i++){
                        row.append(t.getHead()[i].get_name());
                        row.append(",");
                    }
                    ui->textEdit->append(row);
                    row.clear();
                    qDebug()<<t.getData().size();
                    for(int i=0;i<t.getData().size();i++){
                        for(int j=0;j<t.getData()[i].size();j++){
                            row.append(t.getData()[i][j]);
                            row.append(",");
                        }
                       ui->textEdit->append(row);
                       row.clear();
                    }
                    return true;
                }
                else{
                    throw QString("Does not conform to the grammar standard");
                }
            }
            else{
                throw QString("Does not conform to the grammar standard");
            }
            }catch(QString exception){
                throw QString(exception);
            }
        return false;
}

void MainWindow::on_open_triggered()//打开xx
{
     QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),"C:/Users/ywjy/Desktop/data",tr("txt (*.txt)"));//打开文件
}

void MainWindow::on_addtable_triggered()//创建表
{
    QFile file("DBMS/table/success.txt");
    bool ok = file.open(QIODevice::ReadWrite);
}

void MainWindow::on_findtable_triggered()//获取表
{
    QDir dir("DBMS/table");//将目标文件夹下所有文件获取并输出
    QStringList nameFilters;
    nameFilters << "*.jpg" << "*.png" <<"*.txt";
    QStringList files = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
    QString listname = files.join("\n");
    ui->textEdit->setText(listname);
    ui->treeWidget->clear();
    ui->treeWidget->windowFilePath();
    ui->treeWidget->setWindowIconText(listname);

}

void MainWindow::on_backbutton_clicked()//撤销
{
    QFile f("DBMS/cache/cache.txt");//从缓存文件中获取之前的语句内容并还原
    f.open(QIODevice::ReadOnly);
    QTextStream t(&f);
    QString text = t.readAll();
    ui->textEdit->setPlainText(text);
}

void MainWindow::on_pushButton_clicked()//执行
{
    QFile f("DBMS/cache/cache.txt");//将当前输入框内容缓存备份
    f.open(QFile::WriteOnly|QFile::Truncate);
    f.close();
    QString text = ui->textEdit->toPlainText();
    f.open(QFile::WriteOnly|QFile::Truncate);
    QTextStream out(&f);
    out<<text<<endl;
    f.close();


    QString sql = ui->textEdit->toPlainText();
    QStringList sqls = sql.split(";");
    for(int i=0;i<sqls.length();i++){
        sql = sqls.at(i);
        if(!sql.isEmpty()){
            Parse(sql);
            //match(sqls[i]);
        }

    }
//    //insert into course values('800001','计算机基础');
//    //执行语法接口
//    QString textlist = ui->textEdit->toPlainText();
//    f.open(QIODevice::ReadOnly|QIODevice::Text);
//    QByteArray line = f.readLine();
//    QString str(line);
//    QStringList list = str.split(" ");
//    qDebug()<<list[0];

//    QFile fff("DBMS/sys/table/"+list[2]+".txt");
//    fff.open(QIODevice::ReadOnly|QIODevice::Text);
//    QByteArray line2 = fff.readLine();
//    QString str2(line2);
//    QStringList list2 = str2.split(",");
//    fff.close();

//    if(list[0]=="insert"&&list[1]=="into")
//    {
//        if(list2[4]=="1")
//        {
//            QFile ff("DBMS/sys/data/"+list[2]+".txt");
//            ff.open(QFile::WriteOnly|QFile::Truncate);
//            Table t(list[2],"sys");
//            if(t.getData()[0][0]==NULL)
//            {
//                QTextStream out(&ff);
//                out<<list[3]<<endl;
//                ff.close();
//                ui->textEdit->setPlainText("已插入！");
//            }
//            else
//            {
//                ui->textEdit->setPlainText("不满足！");
//            }
//        }
//    }
//    else
//    {
//        ui->textEdit->setPlainText("该语句无法识别！");
//    }
}

void MainWindow::on_clearbutton_clicked()//清除
{

    QFile f("DBMS/cache/cache.txt");//将当前输入框内容缓存备份
    f.open(QFile::WriteOnly|QFile::Truncate);
    f.close();
    QString text = ui->textEdit->toPlainText();
    f.open(QFile::WriteOnly|QFile::Truncate);
    QTextStream out(&f);
    out<<text<<endl;
    f.close();

    ui->textEdit->clear();//清空文本
}

void MainWindow::on_readtable(QString filename,QString databasename)//打开表
{
    tree t(filename,databasename);

    ui->tableWidget->clear();//清空已存在的表
    ui->tableWidget->setColumnCount(t.getHead().size());//根据表结构设置列数
    ui->tableWidget->setRowCount(t.getData().size());//根据数据设置行数

//    ui->tableWidget->horizontalHeader()->setVisible(false);// 隐藏表头
//    ui->tableWidget->verticalHeader()->setVisible(false);

         for(int i=0;i<t.getData().size();i++)//创建视图
         {
             for(int j=0;j<t.getHead().size();j++)
             {
                 ui->tableWidget->setHorizontalHeaderItem(j,new QTableWidgetItem(t.getHead()[j].get_name()));//设置表头

                 if(t.getData()[i][j]==NULL)//判断表中的数据是否存在，若不存在补充null
                 {
                     ui->tableWidget->setItem(i,j,new QTableWidgetItem("(null)"));//读取内容
                 }
                 else//将表中读出的数据输入到表中相应位置
                 {
                     ui->tableWidget->setItem(i,j,new QTableWidgetItem(t.getData()[i][j]));//读取内容

                 }
             }
         }
}

void MainWindow::on_readdb_triggered()//打开数据库
{
    ui->treeWidget->clear();//清空树

    ui->treeWidget->setColumnCount(1);//设置树冠
    QStringList header;
    header<<QString("DB List");//不能使用中文
    ui->treeWidget->setHeaderLabels(header);

    QDir dirdbs("DBMS/database");//获取数据库
    QStringList dbsfiles;
    dbsfiles << "*.jpg" << "*.png" <<"*.txt";
    QStringList dbs = dirdbs.entryList(dbsfiles, QDir::Files|QDir::Readable, QDir::Name);
    QStringList toplevel;//一级节点 数据库
    for(int i=0;i<dbs.size();i++)
    {;
        QStringList dbsname = dbs[i].split(".txt");
        toplevel<<dbsname;
        QTreeWidgetItem *top = new QTreeWidgetItem(ui->treeWidget,toplevel);
        toplevel.clear();

        QDir dir("DBMS/"+dbsname[0]+"/table");//获取对应数据库的表
        QStringList nameFilters;
        nameFilters << "*.jpg" << "*.png" <<"*.txt";
        QStringList files = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
        QStringList seclevel;//二级节点 表
        for(int j=0;j<files.size();j++)
        {
            QStringList tablename = files[j].split(".txt");//增加对应数据库前缀
            QString cache;
            cache.append(dbsname[0]);
            cache.append(".");
            cache.append(tablename[0]);
            seclevel<<cache;//读入文件*1
            QTreeWidgetItem *childitem = new QTreeWidgetItem(top,seclevel);
            top->addChild(childitem);
            seclevel.clear();//清空队列
            QFile file("DBMS/table/"+cache+".txt");
            bool ok = file.open(QIODevice::ReadWrite);//
            file.close();
        }
    }
}

void MainWindow::on_treeWidget_itemSelectionChanged()//点击二级节点后的响应事件
{
    QTreeWidgetItem *item = ui->treeWidget->currentItem();

    QDir dir("DBMS/table");//获取表
    QStringList nameFilters;
    nameFilters << "*.jpg" << "*.png" <<"*.txt";
    QStringList files = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
    QStringList seclevel;//二级节点 表

    if(item->text(0).contains("."))
    {

        QStringList name = item->text(0).split(".");//将二级节点名拆分成数据库名和表名
        tree t(name[1],name[0]);//名字1是表名，名字2是数据库名

        if(t.getData().size()!=NULL)//检测表是否为空
        {
            for(int j=0;j<files.size();j++)
            {
                QStringList tablename = files[j].split(".txt");
                seclevel<<tablename;//读入文件数量
                if(item->text(0)==seclevel[0])//检测表是否存在
                {
                    on_readtable(name[1],name[0]);
                }
                seclevel.clear();//清空队列
            }
        }
        else//如果是空表，输出
        {
            ui->tableWidget->clear();
            ui->tableWidget->setColumnCount(1);
            ui->tableWidget->setRowCount(1);
            ui->tableWidget->setItem(0,0,new QTableWidgetItem("null_table"));
        }
    }
}

