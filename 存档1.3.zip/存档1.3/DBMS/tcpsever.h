#ifndef TCPSEVER_H
#define TCPSEVER_H


class TCPSEVER
{
public:
    TCPSEVER();
};

#endif // TCPSEVER_H
