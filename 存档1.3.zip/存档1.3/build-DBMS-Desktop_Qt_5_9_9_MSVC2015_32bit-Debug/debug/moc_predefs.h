#define _MSC_EXTENSIONS 
#define _MSC_VER 1926
#define _MSC_FULL_VER 192628806
#define _MSC_BUILD 0
#define _WIN32 
#define _M_IX86 600
#define _M_IX86_FP 2
#define _CPPRTTI 
#define _DEBUG 
#define _MT 
#define _DLL 
